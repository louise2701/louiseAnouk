import React from 'react';
import AnimalList from './components/AnimalList';
import StaffList from './components/StaffList';

function App() {
  return (
    <div>
      <h1>Votre titre d'application</h1>
      <AnimalList />
      <StaffList />
    </div>
  );
}

export default App;
