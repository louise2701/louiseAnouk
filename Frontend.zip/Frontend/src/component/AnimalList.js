import React, { useState, useEffect } from 'react';
import axios from 'axios';

function AnimalList() {
  const [animals, setAnimals] = useState([]);

  useEffect(() => {
    // Appel du backend animal pour récupérer la liste des animaux
    axios.get('/animals')
      .then(response => setAnimals(response.data))
      .catch(error => console.error('Erreur lors de la récupération des animaux', error));
  }, []);

  return (
    <div>
      <h2>Liste des Animaux</h2>
      <ul>
        {animals.map(animal => (
          <li key={animal.id}>{animal.species} - {animal.status}</li>
        ))}
      </ul>
    </div>
  );
}

export default AnimalList;
