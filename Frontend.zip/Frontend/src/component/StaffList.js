import React, { useState, useEffect } from 'react';
import axios from 'axios';

function StaffList() {
  const [staff, setStaff] = useState([]);

  useEffect(() => {
    // Appel du backend staff pour récupérer la liste du personnel
    axios.get('/personnel')
      .then(response => setStaff(response.data))
      .catch(error => console.error('Erreur lors de la récupération du personnel', error));
  }, []);

  return (
    <div>
      <h2>Liste du Personnel</h2>
      <ul>
        {staff.map(person => (
          <li key={person.id}>{person.name} - {person.role}</li>
        ))}
      </ul>
    </div>
  );
}

export default StaffList;
