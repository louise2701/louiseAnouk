import axios from 'axios';

const staffService = {
  getAllStaff: async () => {
    try {
      const response = await axios.get('/personnel');
      return response.data;
    } catch (error) {
      console.error('Erreur lors de la récupération du personnel', error);
      throw error;
    }
  },
};

export default staffService;
