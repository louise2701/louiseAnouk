import axios from 'axios';

const animalService = {
  getAllAnimals: async () => {
    try {
      const response = await axios.get('/animals');
      return response.data;
    } catch (error) {
      console.error('Erreur lors de la récupération des animaux', error);
      throw error;
    }
  },
};

export default animalService;
